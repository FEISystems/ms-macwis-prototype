﻿

namespace JsonGenerator
{
    public class ChildCareProvider
    {
        public int Id { get; set; }
        public string ProviderName { get; set; }
        public string LicenseType { get; set; }
        public int ProviderType { get; set; }
        public string ProviderTypeDescription { get; set; }
        public int? ProviderCapacity { get; set; }
        public string PhysicalCity { get; set; }
        public string PhysicalZipCode { get; set; }
        public int? CountyNumber { get; set; }
        public string CountyName { get; set; }
        public string PhoneNumber { get; set; }
        public int QualityRating { get; set; }
        public string QualityRatingDescription { get; set; }
        public int MinAge { get; set; }
        public int MaxAge { get; set; }
        public string Gender { get; set; }
        public string CanTakeChildrenWithBehavioralProblems { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }

        public string HoursofOperation { get; set; }
        public string DaysofOperation { get; set; }
        public string CanTakeChildrenWithMedicalProblems { get; set; }
        public string USDAFoodPrograms { get; set; }
    }
}
