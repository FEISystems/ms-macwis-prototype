﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using Newtonsoft.Json;

namespace JsonGenerator
{
    class Program
    {
        static void Main()
        {
            GenerateJson();
        }

        private static void GenerateJson()
        {
            var category = "providers";
            var readPath = string.Format(@".\sourceData_{0}.csv", category);
            var writePath = string.Format(@".\{0}.json", category);

            var lines = File.ReadLines(readPath).ToList();
            lines.RemoveAt(0);
            char[] charSeparators = {','};
            var providerList = new List<ChildCareProvider>();

            var zipCodeBounds = new Dictionary<string, Geo>();
            var index = 0;
            
            // Mississipi bounds
            /*double maxiLatitude = 34.9961091;
            double miniLatitude = 30.1741032;
            double maxiLongitude = -88.0994304;
            double miniLongitude = -91.65299449999999;*/

            foreach (var line in lines)
            {
                //the first parameter contains special charactor, need to do special process;

                string lastparameters;
                IList<string> parameters = new List<string>();
                if (line.StartsWith("\""))
                {
                    lastparameters = line.Substring(line.IndexOf("\",") + 2);
                    parameters = lastparameters.Split(charSeparators).ToList();

                    var firstparameter = line.Substring(0, line.IndexOf("\",")).TrimStart(Convert.ToChar("\""));
                    firstparameter = firstparameter.Replace("\"\"", "\"");
                    parameters.Insert(0, firstparameter);
                }
                else
                {
                    parameters = line.Split(charSeparators);
                }

                var providerName = parameters[0].Trim();
                var licenseType = parameters[1].Trim();
                var providerType = int.Parse(parameters[2].Trim());
                var providerTypeDescripion = parameters[3].Trim();
                var qualityRating = int.Parse(parameters[4].Trim());
                var qualityRatingDescripion = parameters[5].Trim();
                var providerCapacity = int.Parse(parameters[6].Trim());
                var physicalCity = parameters[7].Trim();
                var physicalZipCode = parameters[8].Trim();
                var countyNumber = int.Parse(parameters[9].Trim());
                var countyName = parameters[10].Trim();
                var phoneNumber = parameters[11].Trim();

                var hoursofOperation = parameters[12].Trim();
                var daysofOperation = parameters[13].Trim();
                

                Random random = new Random();
                var newItem = new ChildCareProvider
                {
                    Id = ++index,
                    ProviderName = providerName,
                    LicenseType = licenseType,
                    ProviderType = providerType,
                    ProviderTypeDescription = providerTypeDescripion,
                    QualityRating = qualityRating,
                    QualityRatingDescription = qualityRatingDescripion,
                    ProviderCapacity = providerCapacity,
                    PhysicalCity = physicalCity,
                    PhysicalZipCode = physicalZipCode,
                    CountyNumber = countyNumber,
                    CountyName = countyName,
                    PhoneNumber = phoneNumber,
                    HoursofOperation = hoursofOperation,
                    DaysofOperation = daysofOperation
                    
                };
                
                newItem.MinAge = random.Next(0, 12);
                Thread.Sleep(10);
                newItem.MaxAge = random.Next(newItem.MinAge, 12);
                Thread.Sleep(10);

                switch (random.Next(0,100)%3)
                {
                    case 0:
                        newItem.Gender = "Boy";
                        break;
                    case 1:
                        newItem.Gender = "Girl";
                        break;
                    case 2:
                        newItem.Gender = "Both";
                        break;
                    default:
                        newItem.Gender = "Both";
                        break;
                }
                Thread.Sleep(10);

                switch (random.Next(0, 100)%2)
                {
                    case 0:
                        newItem.CanTakeChildrenWithBehavioralProblems = "No";
                        break;
                    case 1:
                        newItem.CanTakeChildrenWithBehavioralProblems = "Yes";
                        break;
                    default:
                        newItem.CanTakeChildrenWithBehavioralProblems = "Yes";
                        break;
                }

                 switch (random.Next(0, 100)%2)
                {
                    case 0:
                        newItem.CanTakeChildrenWithMedicalProblems = "No";
                        break;
                    case 1:
                        newItem.CanTakeChildrenWithMedicalProblems = "Yes";
                        break;
                    default:
                        newItem.CanTakeChildrenWithMedicalProblems = "Yes";
                        break;
                }

                switch (random.Next(0, 100)%2)
                {
                    case 0:
                        newItem.USDAFoodPrograms = "No";
                        break;
                    case 1:
                        newItem.USDAFoodPrograms = "Yes";
                        break;
                    default:
                        newItem.USDAFoodPrograms = "Yes";
                        break;
                }

                

                if (!zipCodeBounds.ContainsKey(newItem.PhysicalZipCode))
                {
                    zipCodeBounds.Add(newItem.PhysicalZipCode, new Geo(newItem.PhysicalZipCode));
                }

                var bound = zipCodeBounds[newItem.PhysicalZipCode];
                newItem.Latitude = random.NextDouble()*(bound.maxiLatitude - bound.miniLatitude) + bound.miniLatitude;
                Thread.Sleep(10);
                newItem.Longitude = random.NextDouble()*(bound.maxiLongitude - bound.miniLongitude) + bound.miniLongitude;
                Thread.Sleep(10);

                providerList.Add(newItem);
            }
            var json = JsonConvert.SerializeObject(providerList.ToArray(), Formatting.Indented);

            // Generate the list items
            //var json = JsonConvert.SerializeObject(providerList.Select(x => new County(x.ProviderType, x.ProviderTypeDescripion)).Distinct(new ModelComparer()).OrderBy(y=>y.Id).ToArray(),Formatting.Indented);
            
            //write string to file
            File.WriteAllText(writePath, json);
        }

        public class County
        {
            public County(int id, string name)
            {
                Id = id;
                Name = name;
            }

            public int Id { get; set; }

            public string Name { get; set; }
        }

        public class ModelComparer : IEqualityComparer<County>
        {
            public bool Equals(County x, County y)
            {
                return x.Id == y.Id;
            }
            public int GetHashCode(County obj)
            {
                return obj.Id.GetHashCode();
            }
        }
        
        public class Geo
        {
            public double maxiLatitude { get; set; }
            public double miniLatitude { get; set; }
            public double maxiLongitude { get; set; }
            public double miniLongitude { get; set; }
            
            /// <summary>
            /// default constructor
            /// </summary>
            public Geo()
            {
            }


            /// <summary>
            /// construct geo given name of a place
            /// </summary>
            /// <param name="location"></param>
            public Geo(string location)
            {
                var publicKey = "AIzaSyAMAlk7Y1jfEG-97LQYaZtuF5b2bZeOLk8";
                string url = string.Format("https://maps.google.com/maps/api/geocode/json?key={0}&address={1}",
                    publicKey, location);
                HttpWebRequest request = (HttpWebRequest) WebRequest.Create(url);
                HttpWebResponse response = (HttpWebResponse) request.GetResponse();
                // some zipcode doesn't have bounds data, so use viewport instead;
                //results[0]["geometry"]["bounds"]["northeast"]["lat"];
                using (StreamReader sr = new StreamReader(response.GetResponseStream()))
                {
                    var retureString = sr.ReadToEnd();
                    var results = JsonConvert.DeserializeObject<dynamic>(retureString)["results"];

                    maxiLatitude = results[0]["geometry"]["viewport"]["northeast"]["lat"];
                    maxiLongitude = results[0]["geometry"]["viewport"]["northeast"]["lng"];
                    miniLatitude = results[0]["geometry"]["viewport"]["southwest"]["lat"];
                    miniLongitude = results[0]["geometry"]["viewport"]["southwest"]["lng"];
                }
            }
        }
    }
}
